3919_dho.txt

@data{DVN/6N5V1K_2022,
author = {McOnyango, Owen and Indede, Florence and Wanzare, Lilian D.A. and Wanjawa, Barack and Ombui, Edward and Muchemi, Lawrence},
publisher = {Harvard Dataverse},
title = {{Kencorpus: Kenyan Languages Corpus}},
UNF = {UNF:6:GNe2C+9LlgEU6vMMqRldag==},
year = {2022},
version = {V7},
doi = {10.7910/DVN/6N5V1K},
url = {https://doi.org/10.7910/DVN/6N5V1K}
}

bible.csv

https://github.com/theonize/charis